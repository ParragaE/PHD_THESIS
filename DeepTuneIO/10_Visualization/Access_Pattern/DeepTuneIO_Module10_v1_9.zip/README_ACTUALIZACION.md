# DeepTuneIO Analyzer — Module 10 v1.9

Changes:
- General contention figures 10–12 now show descriptive category names and dynamic experiment metadata.
- Figures 13–14 show relative byte offsets (absolute origin in axis label), operation sizes, overlap duration in milliseconds.
- Figure 15 explicitly distinguishes inferred NFS concurrency from measured slowdown.
- Figure 16 shows the percentage of unique DXT operations involved in candidate pairs (Level 1), not measured performance contention.
- Figure 17 shows Level 2 performance evidence for the selected JobID, using Module 08 Perf and Module 04 Parser; the validation JSON states whether an equivalent baseline is available. No baseline is automatically treated as equivalent.
- Optional CLI: --perf-csv PATH --parser-csv PATH. When omitted, each file is auto-discovered if exactly one matching CSV exists in campaign root.
- Profiles: contention or all. Notebook updated.

Install: copy Module directory over the matching local project Module directory (after backup), open 10_Access_Pattern_Visualization_ABC.ipynb, restart kernel, run.

Scientific limits: Candidate coincidence does not establish storage bottlenecks. IO_Time_s (Perf) and POSIX_F_READ_TIME (Parser) are not interchangeable. Comparisons across distinct access modes cannot establish causal contention. DXT may have incomplete coverage. The candidate ratio denominator is valid DXT events, not all application I/O.
