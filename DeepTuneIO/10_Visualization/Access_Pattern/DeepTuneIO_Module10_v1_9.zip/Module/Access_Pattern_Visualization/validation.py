"""Level-2 evidence. JobID joins only; no causal claims from descriptive counters."""
from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt

METRICS = ('Run_Time_s','IO_Time_s','IO_Time_Ratio','Bandwidth_Darshan_MiB_s',
           'IO_Total_MiB','POSIX_F_READ_TIME','POSIX_BYTES_READ','POSIX_READS')

def _locate(root, supplied, prefix):
    if supplied is not None:
        p=Path(supplied)
        if not p.is_file(): raise FileNotFoundError(f'Evidence file not found: {p}')
        return p
    paths=sorted(Path(root).rglob(prefix+'*.csv'))
    return paths[0] if len(paths)==1 else None

def _read_job(path, job_id):
    if path is None or job_id is None:return None
    df=pd.read_csv(path,low_memory=False)
    key=next((x for x in ('Jobid','JobID','job_id') if x in df),None)
    if key is None:return None
    rows=df.loc[df[key].astype(str)==str(job_id)]
    if len(rows)!=1:return None
    return rows.iloc[0]

def _numeric(row, name):
    if row is None or name not in row:return None
    v=pd.to_numeric(pd.Series([row[name]]),errors='coerce').iloc[0]
    return float(v) if pd.notna(v) else None

def create_validation_products(outdir, meta, job_id, perf_csv=None, parser_csv=None, campaign_root=None):
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    perf=_locate(campaign_root,perf_csv,'08_Perf_') if campaign_root else Path(perf_csv) if perf_csv else None
    parser=_locate(campaign_root,parser_csv,'4_Execution_Summary_') if campaign_root else Path(parser_csv) if parser_csv else None
    p=_read_job(perf,job_id);q=_read_job(parser,job_id)
    rows=[]
    for origin,row,path in [('Module 08 Perf',p,perf),('Module 04 Parser',q,parser)]:
        for metric in METRICS:
            val=_numeric(row,metric)
            if val is not None:rows.append({'job_id':job_id,'source':origin,'metric':metric,'value':val,'source_file':str(path)})
    metrics=outdir/'17_level2_job_metrics.csv';pd.DataFrame(rows,columns=['job_id','source','metric','value','source_file']).to_csv(metrics,index=False)
    diagnostic={'job_id':job_id,'level_1':'DXT spatial/temporal candidate classification',
                'level_2':'descriptive performance indicators; causal contention NOT established',
                'perf_source':str(perf) if perf else None,'parser_source':str(parser) if parser else None,
                'reference_status':'not_validated_no_control_run',
                'missing_evidence':['matched equivalent baseline','per-operation latency or time-aligned storage telemetry'],
                'caution':'Do not equate POSIX_F_READ_TIME with IO_Time_s or use aggregate BW as per-operation latency.'}
    status=outdir/'17_level2_evidence_diagnostics.json';status.write_text(json.dumps(diagnostic,indent=2),encoding='utf-8')
    created=[metrics,status]
    fig,axes=plt.subplots(1,3,figsize=(15,5))
    entries=[('Run_Time_s','Execution time','s'),('IO_Time_s','I/O time (Perf)','s'),('Bandwidth_Darshan_MiB_s','Darshan bandwidth','MiB/s')]
    for ax,(key,title,unit) in zip(axes,entries):
        v=_numeric(p,key)
        if v is None:
            ax.text(.5,.5,'Metric unavailable',ha='center',va='center',transform=ax.transAxes)
        else:
            ax.bar(['Selected job'],[v],color='#397eac',width=.5)
            ax.text(0,v,f'{v:,.3f}',ha='center',va='bottom')
        ax.set(title=title,ylabel=unit)
        ax.grid(axis='y',alpha=.2)
    fig.suptitle(f'Level 2 — Measured Job Performance | JobID {job_id}\nDescriptive evidence only; no matched baseline or causal contention validation',fontsize=13)
    fig.tight_layout(rect=(0,0,1,.86))
    for ext in ('png','pdf'):
        target=outdir/f'17_level2_performance_evidence.{ext}';fig.savefig(target,dpi=160,bbox_inches='tight');created.append(target)
    plt.close(fig)
    return created
